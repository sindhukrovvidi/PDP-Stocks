The program allows the user to create and save the portfolio of stocks and also view them. It
supports the following features. User can
1. create one or more portfolios with one or more companies in it.
2. create multiple portfolios in one go, along with viewing them.
3. view the portfolio which were created.
4. see the current value of his portfolio.
5. speculate the value of his portfolio with in the given time range.
6. throws an IllegalArgumentException if the number of stocks to be entered is less than or equal to
 zero.